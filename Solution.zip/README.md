## PreRequisites
- node > 14.17.0
- go 1.18? (I think lower versions are fine... only using STD Lib)

## Commands
- `npm install`
- `npm run start`
- `npm run test`
- `go run src/main.go`

